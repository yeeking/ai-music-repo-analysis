This is a BETA version of the code used to run experiments for the paper. The next version being released soon will be fully documented and commented. For now, however, you can see how to run an experiment by looking at the script for gpu0.py.                  


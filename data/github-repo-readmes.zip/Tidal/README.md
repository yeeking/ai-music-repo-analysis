
Tidal [![Build Status](https://github.com/tidalcycles/Tidal/workflows/ci/badge.svg)](https://github.com/tidalcycles/Tidal/actions)
=====

Language for live coding algorithmic patterns

For documentation, mailing list and more info see here:  
  https://tidalcycles.org/

You can help speed up Tidal development by contributing to the collective fund here:  
  https://opencollective.com/tidalcycles

(c) Alex McLean and contributors, 2022

Distributed under the terms of the GNU Public license version 3 (or later).


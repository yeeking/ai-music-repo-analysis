# obama-rnn
Obama Political Speech generator - Recurrent Neural Network

Read more here:
https://medium.com/@samim/obama-rnn-machine-generated-political-speeches-c8abd18a2ea0

To run install https://github.com/karpathy/char-rnn

char-rnn cloud setup: https://www.terminal.com/snapshot/f62c5d8da1ba23cae50c55307890259a57e463492d68bb9028d375e95d666a7a

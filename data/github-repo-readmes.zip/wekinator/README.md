# Wekinator

The current version of the Wekinator. 

See much more at www.wekinator.org

All code by Rebecca Fiebrink, except for included libraries (see licenses) and 
WeakListenerSupport.java (see header for full attribution).


